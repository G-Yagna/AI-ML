#!/usr/bin/env python
# coding: utf-8

# ## <span style="font-family: Georgia; font-weight:bold;font-size:1.5em;">Cement manufacturing</span>

# ### Import packages

# In[71]:


import pandas  as pd
import numpy as np
from scipy.stats import randint as sp_randint

from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn import linear_model
from sklearn import svm
from sklearn.linear_model import Ridge
from sklearn.linear_model import Lasso
from sklearn.tree import DecisionTreeRegressor
from sklearn.preprocessing import PolynomialFeatures
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import BaggingRegressor
from sklearn.ensemble import AdaBoostRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import learning_curve

from sklearn.model_selection import validation_curve
from sklearn.model_selection import RandomizedSearchCV
from sklearn.model_selection import GridSearchCV

import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib import pyplot

from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from scipy.stats import zscore
from sklearn.pipeline import make_pipeline

from sklearn.decomposition import PCA

#Finding optimal no. of clusters
from scipy.spatial.distance import cdist


# In[2]:


#Used for Styling
class color:
   BOLD = '\033[1m'
   UNDERLINE = '\033[4m'
   END = '\033[0m'


# ### Deliverable -1

# In[3]:


data=pd.read_csv("concrete.csv",delimiter=',')
data.head()


# #### Univariate Analysis

# In[4]:


print("The DataSet has {} rows and  {} columns".format(data.shape[0],data.shape[1]))


# In[5]:


print(color.UNDERLINE+'The information of the data set:::'+color.END)
data.info()


# In[6]:


data.describe().T


# Independent variables are as follows :
# 
# 1.cement
# 2.slag
# 3.ash
# 4.water
# 5.superplastic
# 6.coarseagg
# 7.fineagg
# 8.age
# 
# Dependent variables :
# 
# strength

# In[7]:


print(color.UNDERLINE+'Checking if any columns are null :::'+color.END)
print(data.isnull().values.any())
print('\n')
print(color.UNDERLINE+'Total null values:::'+color.END)
print(data.isnull().sum().sum())


# In[8]:


dupes = data.duplicated()
print(color.UNDERLINE+color.BOLD+'Duplicates in the DataSet::'+color.END,sum(dupes))
data[data.duplicated()]


# In[9]:


#Outliers
print(color.UNDERLINE+color.BOLD+'Outliers in the DataSet::'+color.END)
data.boxplot(return_type='axes',figsize=(50,20))


# In[10]:


fig, ax = plt.subplots(1,9,figsize=(16,8)) 
sns.distplot(data['cement'],ax=ax[0]) 
sns.distplot(data['slag'],ax=ax[1]) 
sns.distplot(data['ash'],ax=ax[2])
sns.distplot(data['water'],ax=ax[3])
sns.distplot(data['superplastic'],ax=ax[4])
sns.distplot(data['coarseagg'],ax=ax[5])
sns.distplot(data['fineagg'],ax=ax[6])
sns.distplot(data['age'],ax=ax[7])
sns.distplot(data['strength'],ax=ax[8])


# Observation :
# 
# 1. Cement - It is normally distributed where have tail at right side
# 2. slag - It is bi-modal Distribution where we can see 2 clusters/peaks - even this have tail at right side
# 3. ash - Bi-modal & 2 Clusters/peaks - Have tail at right side
# 4. water - Can see 3-4  clusters/peaks and tail on left side
# 5. superplastic - 2 clusters/peaks - looks like tail at right side
# 6. coarseagg- 3 clusters/peaks  - looks like tails is not present
# 7. fineagg - 2 clusters/peaks - Have slight tail at the right hand side
# 8. age - 5 clusters /peaks
# 9. Strength - looks like a normal distribution

# #### Multivariate Analysis

# In[11]:


sns.pairplot(data,diag_kind='kde')


# Observations :
# 
# 1. It looks like from the dataset we can say minimum 2 Gaussians / Clusters are present and max we can say there are 5-6 Clusters/Gaussians
# 2. As from the above pair plot we can say that each attribute looks independent to each other  - we'll conclude this based on correlation value
#     
# 

# In[12]:


corr=data.corr()
fig, ax = plt.subplots(figsize=(10,10))
sns.heatmap(corr,annot=True,linewidth=0.05,ax=ax, fmt= '.2f');


# We can see that there is no high correlation between any two attributes. But negative correlation is between
# 
# 1. Superplastics vs water
# 2. fineagg vs water

# #### Performing data clean and scaling

# In[13]:


### Remove duplicates 
dupes = data.duplicated()
print(color.UNDERLINE+color.BOLD+'Duplicates in the DataSet before::'+color.END,sum(dupes))

data_clean= data.copy()
data_clean=data_clean.drop_duplicates(keep="first")

dupes1 = data_clean.duplicated()
print(color.UNDERLINE+color.BOLD+'Duplicates in the DataSet After::'+color.END,sum(dupes1))


# In[14]:


# Remove Outliers
def remove_outliers(col):
    Q1 = data_clean[col].quantile(0.25)
    Q3 = data_clean[col].quantile(0.75)
    IQR = Q3 - Q1
    for i in np.where(data_clean[col] > Q3 + 1.5 * IQR):
        data_clean[col].iloc[i] = Q3 + 1.5 * IQR
    return data_clean[col]


# In[15]:


col=data_clean.columns


# In[16]:


for i in col:
    if(i != 'strength'):
        remove_outliers(i)


# In[17]:


print(color.UNDERLINE+color.BOLD+'Outliers in the DataSet after removing them::'+color.END)
data_clean.boxplot(return_type='axes',figsize=(50,20))


# In[18]:


# Dealing with the missing values
imputer = SimpleImputer(missing_values=np.nan, strategy='median')
imputer.fit_transform(data_clean)

data_imputed=pd.DataFrame(imputer.transform(data_clean))
data_imputed.columns=col

data_imputed


# #### Data Scaling
# 

# In[19]:


# independant variables
X = data_imputed.drop(['strength'], axis=1)
# the dependent variable
y = data_imputed[['strength']]


# In[20]:


data_imputed_scaled=data_imputed.apply(zscore)
X_scaled=X.apply(zscore)
X_scaled.head()

y_scaled=y.apply(zscore)


# ### Deliverable -2
# 
# To check whether to drop any features we'll apply PCA (Principal Component analysis)  so that we'll include only few attributes

# ##### a. Feature Engineering

# In[21]:


pca = PCA(n_components=8)
pca.fit(X_scaled)


# In[22]:


#eigen_vectors
print('eigen vectors:::')
print(pca.components_)
print('')
#eigen_values
print('Eigen Values:::')
print(pca.explained_variance_)


# In[23]:


plt.bar(list(range(1,9)),pca.explained_variance_ratio_,alpha=0.5, align='center')
plt.ylabel('Variation explained')
plt.xlabel('eigen Value')
plt.show()


# ##### Cumulative variance

# In[24]:


print(pca.explained_variance_ratio_)

cum_var_exp = np.cumsum(pca.explained_variance_ratio_)
pd.DataFrame(cum_var_exp,columns=['Cumul Variance Explanation'],index=['1','2','3','4','5','6','7','8'])


# In[25]:


plt.step(list(range(1,9)),np.cumsum(pca.explained_variance_ratio_), where='mid')
plt.ylabel('Cum of variation explained')
plt.xlabel('eigen Value')
plt.show()


# So we can say that 6 attributes give 95% of the dataset variance. So we'll take these 6 variables

# In[26]:


pca6 = PCA(n_components=6)
pca6.fit(X_scaled)
print(pca6.components_)
print(pca6.explained_variance_ratio_)
Xpca6 = pca6.transform(X_scaled)
Xpca6


# In[27]:


print('Independent Variables:')
print(Xpca6)
print('')
print('Dependent Variable::')
print(y_scaled)


# ##### b. Decide on complexity of the model, should it be simple linear model in terms of parameters or would a quadratic or higher degree help
# 
# Here in the model building i am going to apply both the linear and polynomial regression and compare it's complexity in forthcoming section
# 
# 1. Linear Regression
# 2. Polynomial Features
# 
# 2. SVR
# 3. Ridge Regression
# 4. Lasso Regression
# 
# 6. Decision Tree
# 7. Random Forest
# 8. Bagging
# 9. Ada Boost
# 10. Gradient Boost

# ##### c. Explore Gaussians

# Here we grouping data into clusters . Min 1 to Max 6 as from our pair plot where we can see min 1 peak and max of 5-6 peaks
# 
# Using K-Means Clustering to divide the data in to  clusters
# 
# Here applying cluster check for both Scaled and unscaled data . Applying to data with only 6 attributes and taking the best cluster value

# In[28]:


def cluster_check(d):
    clusters=range(1,7)
    meanDistortions=[]
    for k in clusters:
        model=KMeans(n_clusters=k)
        model.fit(d)
        prediction=model.predict(d)
        meanDistortions.append(sum(np.min(cdist(d, model.cluster_centers_, 'euclidean'), axis=1)) / d.shape[0])
    #To plot the graph
    plt.plot(clusters, meanDistortions, 'bx-')
    plt.xlabel('k')
    plt.ylabel('Average distortion')
    plt.title('Selecting k with the Elbow Method')


# In[29]:


print('For Unscaled data : 3 Clusters are best from the Elbow Method')
cluster_check(data_imputed)


# In[30]:



print('For scaled data : 2 Clusters are best from the Elbow Method')
cluster_check(data_imputed_scaled)


# In[31]:


print('Checking Elbow method for only 6 attributes')
cluster_check(Xpca6)


# We can say that 2 clusters looks good so applying 2 clusters

# In[32]:


# Let us first start with K = 3
final_model=KMeans(2)
final_model.fit(data_imputed_scaled)
prediction=final_model.predict(data_imputed_scaled)

#Append the prediction 
data_imputed_scaled["GROUP"] = prediction
print("Groups Assigned : \n")
data_imputed_scaled.head()


# In[33]:


techSuppClust = data_imputed_scaled.groupby(['GROUP'])
techSuppClust.mean()


# In[34]:


data_imputed_scaled.boxplot(by='GROUP', layout = (3,3),figsize=(15,10))


# In[35]:


def lmplot(var):
    with sns.axes_style("white"):
        plot = sns.lmplot(var,'strength',data=data_imputed_scaled,hue='GROUP')
    plot.set(ylim = (-3,3));


# In[36]:



lmplot('cement')
lmplot('age')
lmplot('ash')
lmplot('coarseagg')
lmplot('fineagg')
lmplot('superplastic')
lmplot('water')


# Observations :
# 
# 1. Straight line -- means there is week relation between that cluster and varaible. Below are few cases
#      
#      Coarseagg : weak relation between the cluster 0 of coarseagg and strength
#     
#      ash : weak relation between the cluster 0 of ash and strength
#   
#      fineagg : fineagg cluster 1
# 
# 2. Positive Correlation between cluster and variable:
#     
#     Cement : Both the cluster's in Cement have positive correlation with strength
#     
#     age : Both the cluster's in age have positive correlation with strength
#     
#     superplastic : Both the cluster's in superplastic have positive correlation with strength
#     
#     Water : Cluster 0 of water have positive correlation with strength
#     
# 3. Negative Correlation between cluster and Varaible
# 
#    Cluster 1 of water with Strength
#    
#    Cluster 0 of fineagg
#    
#    Cluster 1 of ash

# ### Deliverable -3
# 
# Here i am using only 6 attributes which we get from PCA for model building
# 
# Here dividing the dataset into 3 parts - Train, validate and test
# 60% - train set,
# 20% - validation set,
# 20% - test set
# 
# Where train is used in this section where Validate will be used in next section while doing the hyperparameter tuning
# 
# Here Xpca6 is the set we are dividing into train , validate and test - First divide into 60:40 and again divide 40 into validate and test

# In[37]:


print('Independent Variables:')
print(Xpca6)
print('')
print('Dependent Variable::')
print(y_scaled)


# #### Spliting data into 60% training , 20% validate and 20% Test

# In[38]:


x_train, x_valtest, y_train, y_valtest = train_test_split(Xpca6, y_scaled, test_size=0.4, random_state=1)
x_val, x_test, y_val, y_test = train_test_split(x_train, y_train, test_size=0.4, random_state=1)


# #### Building model on the train data

# In[39]:


def R2_Score(model,x_train,y_train):
    print(model.score(x_train, y_train))
    


# ##### a. Linear Regression

# In[40]:


regression_model = LinearRegression()
regression_model.fit(x_train, y_train)
print(color.UNDERLINE+'(R^2) Score of Linear Regression model on train data::'+color.END)
R2_Score(regression_model,x_train,y_train)
print(color.UNDERLINE+'(R^2) Score of Linear Regression model on Validation data::'+color.END)
R2_Score(regression_model,x_val,y_val)


# ##### b. Polynomial Features

# In[41]:


#Here using degree 2
poly = PolynomialFeatures(degree=2, interaction_only=True)
x_train_poly = poly.fit_transform(x_train)
x_test_poly = poly.fit_transform(x_test)
x_val_poly = poly.fit_transform(x_val)
poly_clf = linear_model.LinearRegression()
poly_clf.fit(x_train_poly, y_train)
print(color.UNDERLINE+'(R^2) Score of Polynomial of degree 2 Linear Regression model on train data::'+color.END)
R2_Score(poly_clf,x_train_poly,y_train)
print(color.UNDERLINE+'(R^2) Score of Polynomial of degree 2 Linear Regression model on Validation data::'+color.END)
R2_Score(poly_clf,x_val_poly,y_val)


# In[42]:


#Here using degree 3
poly = PolynomialFeatures(degree=3, interaction_only=True)
x_train_poly3 = poly.fit_transform(x_train)
x_test_poly3 = poly.fit_transform(x_test)
x_val_poly3 = poly.fit_transform(x_val)
poly_clf = linear_model.LinearRegression()
poly_clf.fit(x_train_poly3, y_train)
print(color.UNDERLINE+'(R^2) Score of Polynomial of degree 3 Linear Regression model on train data::'+color.END)
R2_Score(poly_clf,x_train_poly3,y_train)
print(color.UNDERLINE+'(R^2) Score of Polynomial of degree 3 Linear Regression model on Validation data::'+color.END)
R2_Score(poly_clf,x_val_poly3,y_val)


# ##### c. SVR

# In[43]:


svr_clf = svm.SVR()
svr_clf.fit(x_train, y_train)
print(color.UNDERLINE+'(R^2) Score of Linear Regression model on train data::'+color.END)
R2_Score(svr_clf,x_train,y_train)
print(color.UNDERLINE+'(R^2) Score of Linear Regression model on Validation data::'+color.END)
R2_Score(svr_clf,x_val,y_val)


# ##### d. Regularization models
# ##### d.1 .Ridge

# In[44]:


ridge = Ridge(alpha=.3)
ridge.fit(x_train, y_train)
print(color.UNDERLINE+'(R^2) Score of Ridge regression on train data::'+color.END)
R2_Score(ridge,x_train,y_train)
print(color.UNDERLINE+'(R^2) Score of Ridge regression on validation data::'+color.END)
R2_Score(ridge,x_val,y_val)


# ##### d.2 .Lasso

# In[45]:


lasso = Lasso(alpha=0.1)
lasso.fit(x_train, y_train)
print(color.UNDERLINE+'(R^2) Score of Lasso regression on train data::'+color.END)
R2_Score(lasso,x_train,y_train)
print(color.UNDERLINE+'(R^2) Score of Lasso regression on validation data::'+color.END)
R2_Score(lasso,x_val,y_val)


# ##### e. Decision Tree

# In[46]:


decision_clf = DecisionTreeRegressor(random_state=1,max_depth=5)
decision_clf.fit(x_train, y_train)
print(color.UNDERLINE+'(R^2) Score of Decision Tree regression on train data::'+color.END)
R2_Score(decision_clf,x_train,y_train)
print(color.UNDERLINE+'(R^2) Score of Decision Tree regression on Validation data::'+color.END)
R2_Score(decision_clf,x_val,y_val)


# ##### e. Random Forest

# In[47]:


random_clf=RandomForestRegressor()
random_clf.fit(x_train, y_train)
print(color.UNDERLINE+'(R^2) Score of Random Forest regression on train data::'+color.END)
R2_Score(random_clf,x_train,y_train)
print(color.UNDERLINE+'(R^2) Score of Random Forest regression on Validation data::'+color.END)
R2_Score(random_clf,x_val,y_val)


# ##### f. Bagging

# In[48]:


bag_clf=BaggingRegressor()
bag_clf.fit(x_train, y_train)
print(color.UNDERLINE+'(R^2) Score of Bagging regression on train data::'+color.END)
R2_Score(bag_clf,x_train,y_train)
print(color.UNDERLINE+'(R^2) Score of Bagging regression on Validation data::'+color.END)
R2_Score(bag_clf,x_val,y_val)


# ##### g. Boosting Algorithms
# #### g.1 ADABoost

# In[49]:


adaboost_clf=AdaBoostRegressor()
adaboost_clf.fit(x_train, y_train)
print(color.UNDERLINE+'(R^2) Score of ADABoost regression on train data::'+color.END)
R2_Score(adaboost_clf,x_train,y_train)
print(color.UNDERLINE+'(R^2) Score of ADABoost regression on Validation data::'+color.END)
R2_Score(adaboost_clf,x_val,y_val)


# #### g.2 GradientBoost

# In[50]:


gradientboost_clf=GradientBoostingRegressor()
gradientboost_clf.fit(x_train, y_train)
print(color.UNDERLINE+'(R^2) Score of Gradient Boost regression on train data::'+color.END)
R2_Score(gradientboost_clf,x_train,y_train)
print(color.UNDERLINE+'(R^2) Score of Gradient Boost regression on Validation data::'+color.END)
R2_Score(gradientboost_clf,x_val,y_val)


# Observations :
# 1. As from a and b if the polynomial degree increases the score increases in  linear Regression model and polynomial features
# 2. Among all the models the accuracy score decreases compared to train data in validate data. But in the Random Forest the decrease is small
# 3. So Considering RandomForest in next section while checking on test data

# ### Deliverable -4
# #### a. Algorithms that you think will be suitable for this project
# Among all the above I am considering RandomForest Algorithm where it's accuracy on train and validate data is slighlt different
# and applying RandamizedSearchCV and check how the accuracy is being changed
# (R^2) Score of Random Forest regression on train data::
# 0.9686619665729648
# 
# (R^2) Score of Random Forest regression on Validation data::
# 0.9630783033756551
# 
# And i'm working on Gradient Boost Algorithm also and checking how its performance is effecting after applying RandamizedSearchCV

# #### b. Algorithms that you think will be suitable for this project
# ##### b.1. RandomForest
# 
# Doing it on the validation data set

# In[51]:


estimator = RandomForestRegressor()
estimator.get_params()


# In[53]:


search_grid={'n_estimators':[100,200,300,400,500,600],"criterion": ["mse", "mae"],"max_features": ["auto", "sqrt", "log2"],"bootstrap": [True, False],"min_samples_leaf": [1,2,3,4,5],"min_samples_split": [2,3,4,5]}
samples = 10  # number of random samples 
randomCV = RandomizedSearchCV(estimator, param_distributions=search_grid, n_iter=samples) 
randomCV.fit(x_val, y_val)
print(randomCV.best_params_)


# In[54]:


random_clf_param=RandomForestRegressor(bootstrap= False, criterion= 'mse', max_features= 'log2', min_samples_leaf= 1, min_samples_split= 3, n_estimators= 200)
random_clf_param.fit(x_train, y_train)
print(color.UNDERLINE+'(R^2) Score of Random Forest regression on train data::'+color.END)
R2_Score(random_clf_param,x_train,y_train)
print(color.UNDERLINE+'(R^2) Score of Random Forest regression on Validation data::'+color.END)
R2_Score(random_clf_param,x_val,y_val)


# ##### b.2. GradientBoost
# 
# Doing it on the validation dataset

# In[55]:


estimator1=GradientBoostingRegressor()
search_grid={'n_estimators':[100,200,300,400,500,600],'learning_rate':[.001,0.01,.1],'max_depth':[1,2,3,4,5],'subsample':[.5,.75,1],'random_state':[1]}
samples = 10
search=RandomizedSearchCV(estimator1, param_distributions=search_grid, n_iter=samples) 
search.fit(x_val,y_val)
search.best_params_


# In[57]:


GraBR = GradientBoostingRegressor(learning_rate= 0.01,max_depth= 4,n_estimators= 500,random_state= 1,subsample= 0.5)
GraBR.fit(x_train, y_train)
print(color.UNDERLINE+'(R^2) Score of Gradient Boost regression on train data::'+color.END)
R2_Score(GraBR,x_train,y_train)
print(color.UNDERLINE+'(R^2) Score of Gradient Boost regression on Validation data::'+color.END)
R2_Score(GraBR,x_val,y_val)


# As we can see in Random Forest the performance increased and in Gradient Boost it is increased after applying RandamizedSearch CV
# 
# As from performance we can say Random Forest increased more than Gradient Boost but we'll check this accuracy with test data for these two algorithms
# before applying and after applying RandamizedSearchCV
# 

# In[58]:


#Before
print(color.UNDERLINE+'Before:::(R^2) Score of Gradient Boost regression on Test data::'+color.END)
R2_Score(gradientboost_clf,x_test,y_test)
#After
print(color.UNDERLINE+'After:::(R^2) Score of Gradient Boost regression on Test data::'+color.END)
R2_Score(GraBR,x_test,y_test)


# In[59]:


#Before
print(color.UNDERLINE+'Before ::: (R^2) Score of Random Forest regression on test data::'+color.END)
R2_Score(random_clf,x_test,y_test)
print(color.UNDERLINE+'After ::: (R^2) Score of Random Forest regression on test data::'+color.END)
R2_Score(random_clf_param,x_test,y_test)


# Observation:
# 
# Random Forest algorithm shows large variance in the performance

# #### c. Model performance range at 95% confidence level 

# In[60]:


num_folds = 50
seed = 7

kfold = KFold(n_splits=num_folds, random_state=seed)
results = cross_val_score(random_clf_param, Xpca6, y_scaled, cv=kfold)
print(results)
print("Accuracy: %.3f%% (%.3f%%)" % (results.mean()*100.0, results.std()*100.0))


# In[62]:


pyplot.hist(results)
pyplot.show()
# confidence intervals
alpha = 0.95                             # for 95% confidence
p = ((1.0-alpha)/2.0) * 100              # tail regions on right and left .25 on each side indicated by P value (border)
lower = max(0.0, np.percentile(results, p))  
p = (alpha+((1.0-alpha)/2.0)) * 100
upper = min(1.0, np.percentile(results, p))
print('%.1f confidence interval apprx. %.1f%% and %.1f%%' % (alpha*100, lower*100, upper*100))


# Observation:
# 
# 95% Confidence interval means mean(+/-) 2* Standard deviation So expected to be in range approximately 68 to 100% which is good and acceptable

# Note : I've run the RandamizedSearchCV multiple times for both Random Forest and Gradient Boosting and finalized with the values that gave high change in accuracy. The values for randamizedsearchcv changes with every run

# We can use Learning Curve to visualize the performance metric over a range of values for same hyperparameters to check whether the given data set is overfit or underfit

# In[74]:


pipeline = make_pipeline(StandardScaler(), RandomForestRegressor())
#
# Use learning curve to get training and test scores along with train sizes
#
train_sizes, train_scores, test_scores = learning_curve(estimator=pipeline, X=x_train, y=y_train,
                                                       cv=10, train_sizes=np.linspace(0.1, 1.0, 10),
                                                     n_jobs=1)


# In[75]:


# Calculate training and test mean and std
#
train_mean = np.mean(train_scores, axis=1)
train_std = np.std(train_scores, axis=1)
test_mean = np.mean(test_scores, axis=1)
test_std = np.std(test_scores, axis=1)
#
# Plot the learning curve
#
plt.plot(train_sizes, train_mean, color='blue', marker='o', markersize=5, label='Training Accuracy')
plt.fill_between(train_sizes, train_mean + train_std, train_mean - train_std, alpha=0.15, color='blue')
plt.plot(train_sizes, test_mean, color='green', marker='+', markersize=5, linestyle='--', label='Validation Accuracy')
plt.fill_between(train_sizes, test_mean + test_std, test_mean - test_std, alpha=0.15, color='green')
plt.title('Learning Curve')
plt.xlabel('Training Data Size')
plt.ylabel('Model accuracy')
plt.grid()
plt.legend(loc='lower right')
plt.show()


# Observation:
# 
# 1. A good fit is identified by a training and validation loss that decreases to a point with a minimal gap between the two final  values.
# 2. From this we can say thatthe differnce in the model accuracy for train and validation becomes less when the values increases so we can say that it is neither a overfit nor underfit
# 
# Underfit -- if Training curve decreases and continues to decrease at the end to the plot
# Overfit -- The Curve of training  continues to decrease.The Curve of validation  decreases to a point and begins increasing again.
# 
# Over Plot doesn't comes under the above two cases
# 
